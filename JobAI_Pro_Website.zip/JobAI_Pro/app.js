const $ = (id) => document.getElementById(id);
const toast = (message) => {
  const el = $('toast'); el.textContent = message; el.classList.add('show');
  clearTimeout(window.toastTimer); window.toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
};
const clean = (value) => (value || '').trim();

$('menuBtn').addEventListener('click', () => $('navLinks').classList.toggle('open'));
document.querySelectorAll('#navLinks a').forEach(a => a.addEventListener('click', () => $('navLinks').classList.remove('open')));
document.querySelectorAll('[data-scroll]').forEach(btn => btn.addEventListener('click', () => $(btn.dataset.scroll).scrollIntoView({behavior:'smooth'})));

let lastResume = '';
$('resumeForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const name = clean($('fullName').value), role = clean($('targetRole').value);
  const skills = clean($('skills').value).split(',').map(s=>s.trim()).filter(Boolean);
  const text = [
    name.toUpperCase(),
    [clean($('email').value), clean($('phone').value)].filter(Boolean).join(' | '),
    '',
    'TARGET ROLE',
    role,
    '',
    'PROFESSIONAL SUMMARY',
    clean($('summary').value) || 'Add a short, truthful summary of your strengths and career goals.',
    '',
    'SKILLS',
    skills.length ? skills.join(' • ') : 'Add relevant skills you can confidently demonstrate.',
    '',
    'EDUCATION',
    clean($('education').value) || 'Add your education details.',
    '',
    'EXPERIENCE / PROJECTS',
    clean($('experience').value) || 'Add relevant experience or projects. Do not claim experience you do not have.'
  ].join('\n');
  lastResume = text;
  $('resumeText').textContent = text;
  $('resumeOutput').classList.remove('hidden');
  $('resumeOutput').scrollIntoView({behavior:'smooth',block:'nearest'});
});
$('clearResume').addEventListener('click', () => { $('resumeForm').reset(); $('resumeOutput').classList.add('hidden'); lastResume=''; });
$('copyResume').addEventListener('click', () => copyText(lastResume));
$('downloadResume').addEventListener('click', () => downloadText('resume-draft.txt', lastResume));

function copyText(text) {
  if (!text) return toast('Generate the text first.');
  if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(text).then(()=>toast('Copied to clipboard.')).catch(()=>fallbackCopy(text));
  else fallbackCopy(text);
}
function fallbackCopy(text) {
  const ta=document.createElement('textarea'); ta.value=text; document.body.appendChild(ta); ta.select();
  try { document.execCommand('copy'); toast('Copied to clipboard.'); } catch(e) { toast('Copy not available; select and copy the text.'); }
  ta.remove();
}
function downloadText(filename, text) {
  const blob = new Blob([text], {type:'text/plain;charset=utf-8'});
  const url = URL.createObjectURL(blob); const a=document.createElement('a');
  a.href=url; a.download=filename; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}

function tokens(text) {
  const stop = new Set(['the','and','for','with','you','your','are','our','this','that','from','have','has','will','can','all','any','not','job','role','work','years','year','who','what','when','where','how','into','about','their','they','them','its','was','were','been','being','able','must','should','would','could','such','more','than','then','also','other','required','preferred','skills','experience','using','use','team','good','strong','excellent','including','responsibilities','requirements','candidate','candidates','company','position','within','across','based','support']);
  return [...new Set((text.toLowerCase().match(/[a-z][a-z+#.-]{2,}/g)||[]).filter(w=>!stop.has(w)))];
}
$('checkAts').addEventListener('click', () => {
  const resume=clean($('atsResume').value), jd=clean($('atsJob').value);
  if (!resume || !jd) return toast('Paste both resume text and job description first.');
  const jdTokens=tokens(jd), resTokens=new Set(tokens(resume));
  const present=jdTokens.filter(w=>resTokens.has(w)), missing=jdTokens.filter(w=>!resTokens.has(w));
  const score=Math.round((present.length/Math.max(jdTokens.length,1))*100);
  $('atsOutput').innerHTML=`<div class="result-top"><div class="match-number">${score}%</div><div><b>Keyword overlap estimate</b><p>${present.length} of ${jdTokens.length} unique job-description terms also appear in your resume.</p></div></div><p><b>Terms found</b></p><div class="keyword-pills">${present.slice(0,45).map(w=>`<span>${escapeHtml(w)}</span>`).join('')||'<span>No matching terms found</span>'}</div><p style="margin-top:18px"><b>Terms to review</b></p><div class="keyword-pills">${missing.slice(0,45).map(w=>`<span class="missing">${escapeHtml(w)}</span>`).join('')||'<span>All extracted terms overlap</span>'}</div><p class="small-note">This is a simple text comparison, not a real ATS score. Only add a skill or keyword if it truthfully reflects your experience. Job descriptions may contain common words and irrelevant terms.</p>`;
  $('atsOutput').classList.remove('hidden');
});
function escapeHtml(str){return str.replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}

let coverDraft='';
$('makeCover').addEventListener('click', () => {
  const name=clean($('coverName').value)||'[Your Name]', company=clean($('companyName').value)||'[Company Name]', role=clean($('coverRole').value)||'[Job Title]', strength=clean($('strength').value)||'[relevant skill or strength]', why=clean($('coverWhy').value);
  coverDraft=`Dear Hiring Team,\n\nI am writing to express my interest in the ${role} position at ${company}. I am keen to contribute thoughtfully, learn quickly, and carry out the responsibilities of this role with care.\n\nOne strength I can bring is ${strength}. I would welcome the opportunity to explain how my skills and experience relate to the role. ${why ? 'I am particularly interested in this opportunity because ' + why.replace(/[.]+$/,'') + '.' : 'I am interested in learning more about your team and the needs of this position.'}\n\nThank you for considering my application. I would appreciate the opportunity to discuss my suitability for the role.\n\nSincerely,\n${name}`;
  $('coverText').textContent=coverDraft; $('coverOutput').classList.remove('hidden'); $('coverOutput').scrollIntoView({behavior:'smooth',block:'nearest'});
});
$('copyCover').addEventListener('click',()=>copyText(coverDraft));

$('searchJobs').addEventListener('click', () => {
  const q=clean($('jobQuery').value), loc=clean($('jobLocation').value);
  if (!q) return toast('Enter a job title or skill to search.');
  const query=[q,loc].filter(Boolean).join(' ');
  window.open('https://www.google.com/search?q='+encodeURIComponent(query+' jobs')+'&ibp=htl;jobs','_blank','noopener,noreferrer');
});

const STORAGE_KEY='jobai-pro-tracker-v1';
let applications=[];
try { applications=JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]'); if(!Array.isArray(applications)) applications=[]; } catch(e){applications=[];}
function saveApps(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(applications));}catch(e){toast('Could not save in this browser.');} renderApps();}
function renderApps(){
  $('totalCount').textContent=applications.length;
  $('appliedCount').textContent=applications.filter(a=>['Applied','Interview','Offer','Rejected'].includes(a.status)).length;
  $('interviewCount').textContent=applications.filter(a=>a.status==='Interview').length;
  const rows=$('trackerRows');
  if(!applications.length){rows.innerHTML='<tr><td colspan="4" class="empty-state">No applications yet. Add your first one above.</td></tr>';return;}
  rows.innerHTML=applications.map(a=>`<tr><td>${escapeHtml(a.company)}</td><td>${escapeHtml(a.role)}</td><td><select class="status-select" data-status="${a.id}" aria-label="Application status">${['To apply','Applied','Interview','Offer','Rejected'].map(s=>`<option ${s===a.status?'selected':''}>${s}</option>`).join('')}</select></td><td><button class="delete-btn" data-delete="${a.id}">Delete</button></td></tr>`).join('');
  rows.querySelectorAll('[data-status]').forEach(el=>el.addEventListener('change',()=>{const a=applications.find(x=>x.id===el.dataset.status);if(a){a.status=el.value;saveApps();}}));
  rows.querySelectorAll('[data-delete]').forEach(el=>el.addEventListener('click',()=>{applications=applications.filter(x=>x.id!==el.dataset.delete);saveApps();toast('Application removed.');}));
}
$('trackerForm').addEventListener('submit',e=>{
  e.preventDefault();
  applications.unshift({id:String(Date.now())+Math.random().toString(16).slice(2),company:clean($('trackCompany').value),role:clean($('trackRole').value),status:$('trackStatus').value,createdAt:new Date().toISOString()});
  saveApps();$('trackerForm').reset();toast('Application added to your tracker.');
});
$('exportTracker').addEventListener('click',()=>{
  if(!applications.length)return toast('Add an application before exporting.');
  const rows=[['Company','Role','Status','Added date'],...applications.map(a=>[a.company,a.role,a.status,(a.createdAt||'').slice(0,10)])];
  const csv=rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');
  downloadText('jobai-application-tracker.csv',csv);
});
renderApps();
