JOBAI PRO — MOBILE-FRIENDLY STARTER WEBSITE

WHAT IS INCLUDED
- index.html: website page
- styles.css: responsive styling
- app.js: browser-based resume draft, keyword comparison, cover-letter draft, job search links, and application tracker

IMPORTANT LIMITATIONS
- This is a functional starter/demo, not a connected generative-AI service.
- Resume and cover-letter tools use templates in the browser. The keyword checker is a simple text comparison and does not calculate a real ATS score.
- Job Finder opens an external search. It does not scrape job sites or guarantee vacancies.
- Application tracker data is saved in this browser's localStorage only.
- No account system, cloud database, payment system, or API is connected.
- Do not enter highly sensitive personal information. Review all content before applying.
- Never place an AI API key in public frontend JavaScript. Real AI features need a secure server-side function and an API provider.

HOW TO DEPLOY TO NETLIFY FROM A PHONE
1. Extract/unzip JobAI_Pro.zip on your phone. You should see the JobAI_Pro folder containing index.html, styles.css, app.js, and README.txt.
2. In Netlify, open your site dashboard and find the manual deploy / deploy manually area (the wording may vary).
3. Upload or drag the extracted JobAI_Pro folder (or the folder's contents, depending on the upload screen). Do not upload only the ZIP if Netlify asks for a folder.
4. Wait for the deploy to finish and open the generated site URL.
5. Test the Resume Builder, ATS Keyword Checker, Cover Letter Writer, Job Finder, and Tracker on your phone.

If the mobile browser cannot select a folder, extract the ZIP first and use Netlify's available upload flow. The UI can change; use Netlify's official help centre if the upload option differs.

NEXT STEP FOR A REAL PRODUCT
To add genuine AI responses, use a server-side function (for example, a Netlify Function) connected to an AI provider. Store API keys only in Netlify environment variables, add usage limits, privacy disclosures, and error handling. Before charging users, add authentication, secure cloud storage, payment handling, and clear terms/privacy policy.
